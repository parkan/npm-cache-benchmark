# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.10.16"></a>
## [0.10.16](https://github.com/medikoo/es5-ext/compare/v0.10.15...v0.10.16) (2017-05-09)


### Features

* add String.prototype.count ([2e53241](https://github.com/medikoo/es5-ext/commit/2e53241))


## Changelog for previous versions

See `CHANGES` file