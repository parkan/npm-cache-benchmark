'use strict';

module.exports = require('./is-implemented')()
	? Number.isInteger
	: require('./shim');
