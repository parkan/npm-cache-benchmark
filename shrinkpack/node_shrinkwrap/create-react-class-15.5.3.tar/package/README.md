# create-react-class

A drop-in replacement for `React.createClass`.

Refer to the [React documentation](https://facebook.github.io/react/docs/react-without-es6.html) for more information.
